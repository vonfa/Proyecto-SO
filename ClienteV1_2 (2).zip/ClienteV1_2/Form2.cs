﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClienteV1_2
{
    public partial class Form2 : Form
    {
        Socket server;

        public Form2()
        {
            InitializeComponent();
            try
            {
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                server.Connect("127.0.0.1", 9050); // Conecta al servidor al iniciar
                MessageBox.Show("Conectado al servidor.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con el servidor: " + ex.Message);
            }
        }



        private async void button4_Click(object sender, EventArgs e)
        {
            if (Porcentaje.Checked) // Caso de porcentaje
            {
                string mensaje = "4/" + username.Text ; // Código 3 para porcentaje
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);


                byte[] msg2 = new byte[512];

                // Recibir respuesta de forma asíncrona
                int bytesRecibidos = await Task.Run(() => server.Receive(msg2));
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos).Split('\0')[0];

                if (respuesta.Contains("4/Juegos ganados"))
                {
                    MessageBox.Show("Los juegos que ha ganado Charlie son: " + respuesta);
                }
                else
                {
                    MessageBox.Show("Introduce a Charlie en username");
                }
            }
        }
    }
}
