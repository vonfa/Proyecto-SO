﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace ClienteV1_2
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

      

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9050);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }


        private async void button4_Click(object sender, EventArgs e)
        {
            if (Register.Checked) // Caso de registro
            {
                string mensaje = "1/" + username.Text + "/" + password.Text; // Código 1 para registro
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);

                // Enviar mensaje de registro de forma asíncrona
                await Task.Run(() => server.Send(msg));

                byte[] msg2 = new byte[512];

                // Recibir respuesta de forma asíncrona
                int bytesRecibidos = await Task.Run(() => server.Receive(msg2));
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos).Split('\0')[0];

                if (respuesta.Contains("1/Registro exitoso"))
                {
                    MessageBox.Show("Te has registrado correctamente.");
                }
                else
                {
                    MessageBox.Show("Error al registrarte: " + respuesta);
                }
            }
            else if (Login.Checked) // Caso de inicio de sesión
            {
                string mensaje = "2/" + username.Text + "/" + password.Text; // Código 2 para login
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);

                // Enviar mensaje de inicio de sesión de forma asíncrona
                await Task.Run(() => server.Send(msg));

                byte[] msg2 = new byte[512];

                // Recibir respuesta de forma asíncrona
                int bytesRecibidos = await Task.Run(() => server.Receive(msg2)); 
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos).Split('\0')[0];

                MessageBox.Show("Respuesta completa recibida: " + respuesta); // Para depuración

                // Evaluar la respuesta del servidor
                if (respuesta.Contains("2/Login exitoso"))
                {
                    MessageBox.Show("Inicio de sesión exitoso, bienvenido " + username.Text);
                }
                else
                {
                    MessageBox.Show("Error al iniciar sesión: " + respuesta);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
