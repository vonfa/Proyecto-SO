#include <mysql.h>
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Estructuras
typedef struct {
    int *sock;
    char Nombre[20];
} Cliente;

typedef struct {
    Cliente cliente[100];
    int numero_clientes;
} Cliente_Lista;

Cliente_Lista Clis;
int contador = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
MYSQL *conn;
int i = 0;
char peticion[512];
char respuesta[512];

// Funci?n para conectar a la base de datos
void conectarBD() {
    conn = mysql_init(NULL);
    if (conn == NULL) {
        printf("Error al crear la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
        exit(1);
    }
    
    conn = mysql_real_connect(conn, "localhost", "root", "mysql", "Championship", 0,NULL, 0);
    if (conn == NULL) {
        printf("Error al inicializar la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
        exit(1);
    }
}

// Funci?n para ejecutar consultas SQL
void ejecutarConsultaSQL(char *sql) {
    if (mysql_query(conn, sql) != 0) {
        fprintf(stderr, "Error en la consulta: %s\n", mysql_error(conn));
        mysql_close(conn);
        exit(EXIT_FAILURE);
    }
}

// Funci?n para atender clientes
void *AtenderCliente(void *socket) {
    int sock_conn;
    int *s;
    s = (int *) socket;
    sock_conn = *s;    
    int ret;

    int terminar = 0;
    while (terminar == 0) {
        ret = read(sock_conn, peticion, sizeof(peticion));
        printf("Recibido\n");
        peticion[ret] = '\0';
        printf("Peticion: %s\n", peticion);
        
        char *p = strtok(peticion, "/");
        int codigo = atoi(p);

        char Nombre[20];
        char Contrasenya[20];

        if (codigo == 0) { // Desconexi?n
        
            terminar = 1;

        } else if (codigo == 1) { // Registro
            p = strtok(NULL, "/");
            strcpy(Nombre, p);
            p = strtok(NULL, "/");
            strcpy(Contrasenya, p);

            char comando[256];
            sprintf(comando, "SELECT Name FROM Player WHERE Name='%s'", Nombre);

            if (mysql_query(conn, comando) == 0) {
                MYSQL_RES *result = mysql_store_result(conn);
                if (mysql_num_rows(result) > 0) {
                    sprintf(respuesta, "1/El usuario %s ya existe", Nombre);
                } else {
                    sprintf(comando, "INSERT INTO Player (Name, Password) VALUES ('%s', '%s')", Nombre, Contrasenya);
                    ejecutarConsultaSQL(comando);
                    sprintf(respuesta, "1/Registro exitoso para %s", Nombre);
                }
                mysql_free_result(result);
            }
            write(sock_conn, respuesta, strlen(respuesta));
			

        } else if (codigo == 2) { // Iniciar sesi?n
            p = strtok(NULL, "/");
            strcpy(Nombre, p);
            p = strtok(NULL, "/");
            strcpy(Contrasenya, p);

            char comando[256];
            sprintf(comando, "SELECT Name FROM Player WHERE Name='%s' AND Password='%s'", Nombre, Contrasenya);

            if (mysql_query(conn, comando) == 0) {
                MYSQL_RES *result = mysql_store_result(conn);
                if (mysql_num_rows(result) > 0) {
                    sprintf(respuesta, "2/Login exitoso exitoso para %s", Nombre);
                } else {
                    sprintf(respuesta, "2/Error: Usuario o contrase?a incorrectos");
                }
                mysql_free_result(result);
            } else {
                sprintf(respuesta, "2/Error al realizar la consulta");
            }
			printf("%s\n",respuesta);

            write(sock_conn, respuesta, strlen(respuesta));
        
	
		
	} else if (codigo == 3) { // Registro
			
		char comando[256];
		sprintf(comando,
				"SELECT Identifier, EndDateTime "
				"FROM Game "
				"WHERE Winner = 'Charlie'");
		if (mysql_query(conn, comando) == 0) {
			MYSQL_RES *result = mysql_store_result(conn);
			MYSQL_ROW row;
			
			if (result && mysql_num_rows(result) > 0) {
				strcpy(respuesta, "4/Juegos ganados por Charlie:");
				while ((row = mysql_fetch_row(result))) {
					char buffer[128];
					sprintf(buffer, " ID: %s, Fecha: %s;", row[0], row[1]);
					strcat(respuesta, buffer);
				}
			} else {
				sprintf(respuesta, "/Error en la consulta.");
			}
			
			printf("%s\n", respuesta);
			write(sock_conn, respuesta, strlen(respuesta));
		}
		}
	else if (codigo ==4)
	{
		
		printf ("Respuesta: %s\n", respuesta);
		// Enviamos respuesta
		write (sock_conn,respuesta, strlen(respuesta));
	}
	if (codigo==2)
	{
		pthread_mutex_lock( &mutex ); //No me interrumpas ahora
		contador = contador +1;
		pthread_mutex_unlock( &mutex); //ya puedes interrumpirme
	}
	sprintf (respuesta,"%d",contador);
	
	
    }
    close(sock_conn);
    return NULL;
}

int main(int argc, char *argv[]) {
    conectarBD();

    int sock_conn, sock_listen;
    struct sockaddr_in serv_adr;

    if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("Error creando socket");
        exit(1);
    }

    memset(&serv_adr, 0, sizeof(serv_adr));
    serv_adr.sin_family = AF_INET;
    serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_adr.sin_port = htons(9050);

    if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0) {
        printf("Error en el bind");
        exit(1);
    }

   	if (listen(sock_listen, 3) < 0)
		printf("Error en el Listen");
	
	contador =0;
	int i;
	int sockets[100];
	pthread_t thread;
	i=0;
	// Bucle para atender a 5 clientes
	for (;;){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf ("He recibido conexion\n");
		
		sockets[i] =sock_conn;
		//sock_conn es el socket que usaremos para este cliente
		
		// Crear thead y decirle lo que tiene que hacer
		
		pthread_create (&thread, NULL, AtenderCliente,&sockets[i]);
		i=i+1;
		
	}

    mysql_close(conn);
    return 0;
}